const nomeUsuario = "<?php echo isset($_SESSION['usuario_nome']) ? $_SESSION['usuario_nome'] : '' ?>";
        
if (nomeUsuario) {
    const mensagemBoasVindas = document.getElementById('mensagemBoasVindas');
    mensagemBoasVindas.textContent = 'Olá, ' + nomeUsuario;
}