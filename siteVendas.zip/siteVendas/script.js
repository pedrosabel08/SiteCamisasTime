
// Extrair parâmetros da URL
const urlParams = new URLSearchParams(window.location.search);
const nomeUsuario = urlParams.get('nome');

// Exibir mensagem de boas-vindas
if (nomeUsuario) {
    const mensagemBoasVindas = document.getElementById('mensagemBoasVindas');
    mensagemBoasVindas.textContent = 'Olá, ' + nomeUsuario;
}