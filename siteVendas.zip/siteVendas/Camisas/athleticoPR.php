<?php
session_start();
$nomeUsuario = isset($_SESSION['usuario_nome']) ? $_SESSION['usuario_nome'] : '';

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/siteVendas/CSS/styleProduto.css">
    <link rel="shortcut icon" href="/siteVendas/ico/294668_nike_icon.ico" type="image/x-icon">
    <title>Sabel Sports</title>

</head>

<body>
    <header>
        <div class="menu">
            <p id="mensagemBoasVindas">
                <?php if ($nomeUsuario): ?>
                    Olá, <?php echo $nomeUsuario; ?>
                <?php endif; ?>
            </p>
            <img src="/siteVendas/img/logoSabelSports.png" alt="logoSabelSports">
            <a href="#">Ajuda</a>
            <a href="/siteVendas/HTML/login.html">Sair</a>
        </div>
        <nav>
            <a href="https://www.nike.com.br/nav?sorting=DescReleaseDate">Lançamentos</a>
            <a href="https://www.nike.com.br/nav/ofertas/emoferta">Ofertas</a>
            <a href="https://www.nike.com.br/sc/masculino-1">Masculino</a>
            <a href="https://www.nike.com.br/sc/feminino-1">Feminino</a>

        </nav>
    </header>

    <main>
        <img src="/siteVendas/img/flamengo2.webp" alt="flamengo" class="camisaFla">
        <div class="descricao">
            <p>CAMISA FLAMENGO HOME (1) 2024/25 ADIDAS TORCEDOR MASCULINA</p>
            <div class="price-compare-container">
                <span class="price-compare">R$299,90</span>
                <span class="price">R$169,90</span>
            </div>
            <div class="tamanho">
                <h4>Tamanho: </h4>
                <div class="filtro-tamanho">
                    <select name="tamanho" id="tamanho">
                        <option value="P">P</option>
                        <option value="M">M</option>
                        <option value="G">G</option>
                        <option value="GG">GG</option>
                        <option value="XGG">XGG</option>
                    </select>
                </div>
            </div>

            <div class="quantidade">
                <h4>Quantidade: </h4>
                <input type="number" value="1" name="quantidade">
            </div>
            <div class="button">
                <input type="submit" value="COMPRAR">
            </div>
        </div>
        <div class="descricao2">
            <p>CAMISA FLAMENGO HOME (1) 2024/25 ADIDAS TORCEDOR MASCULINA</p>
            <h2>Viva a paixão pelo Flamengo com a Camisa Flamengo Home (1) 2024/25 da Adidas, disponível agora no Evolua
                Sports. Esta camisa é mais do que um simples uniforme; é uma expressão de identidade e amor pelo clube
                mais querido do Brasil.

                Desenvolvida com tecnologia de tecido avançada, esta camisa proporciona conforto e frescor
                incomparáveis, seja nas arquibancadas vibrantes do Maracanã, nos encontros com amigos para assistir aos
                jogos ou mesmo durante as atividades do dia a dia. Sinta-se confiante e orgulhoso ao vestir as cores do
                Mengão e apoie seu time com estilo e paixão em todos os momentos.</h2>
            <p> Garanta a sua agora:</p>
            <h2>Não perca tempo para ter a sua Camisa Flamengo Home (1) 2024/25. Clique em comprar agora e faça parte da
                Nação Rubro-Negra com autenticidade e estilo. No Evolua Sports, garantimos entrega rápida e segura para
                todo o Brasil, para que você possa exibir sua paixão pelo Flamengo com orgulho e confiança.

                Seja parte da história do Mengão. Compre agora e faça desta camisa uma peça essencial em seu
                guarda-roupa. Celebre as vitórias e conquistas do Flamengo com entusiasmo e dedicação. Vista-se para a
                vitória, vista-se com a grandeza do Flamengo!</h2>

            <img src="/siteVendas/img/medidas.png" alt="medidas" class="medidas">

        </div>

    </main>
    <footer>
        <p>&copy; 2024 Pedro Sabel.

        </p>
    </footer>

</body>

</html>