<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = limpar_entrada($_POST["email"]);
    $senha = limpar_entrada($_POST["senha"]);

    $conexao = new mysqli('localhost', 'root', 'pedro.amor0808', 'bd_siteVendas', 3307);

    if ($conexao->connect_error) {
        die('Erro na conexão: ' . $conexao->connect_error);
    }

    // Verifica o e-mail e a senha
    $stmt = $conexao->prepare("SELECT email FROM usuarios WHERE email = ? AND senha = ?");
    $stmt->bind_param("ss", $email, $senha);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows == 1) {
        // Recupera o nome do usuário
        $stmt->close(); // Fecha a consulta anterior
        $stmt = $conexao->prepare("SELECT nome FROM usuarios WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->bind_result($nome);
        $stmt->fetch();

        // Inicia a sessão e armazena os dados do usuário
        session_start();
        $_SESSION['usuario_email'] = $email;
        $_SESSION['usuario_nome'] = $nome;

        // Redireciona para a página principal
        header('Location: main.html?nome=' . urlencode($nome));
        exit();
    } else {
        echo "Credenciais incorretas!";
    }

    $stmt->close();
    $conexao->close();
}

function limpar_entrada($entrada)
{
    $entrada = trim($entrada);
    $entrada = stripslashes($entrada);
    $entrada = htmlspecialchars($entrada);
    return $entrada;
}