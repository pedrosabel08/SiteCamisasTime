<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = limpar_entrada($_POST["nome"]);
    $sobrenome = limpar_entrada($_POST["sobrenome"]);
    $cpf = limpar_entrada($_POST["cpf"]);
    $email = limpar_entrada($_POST["email"]);
    $senha = limpar_entrada($_POST["senha"]);


    $conexao = new mysqli("localhost", "root", "pedro.amor0808", "bd_siteVendas", 3307);

    if ($conexao->connect_error) {
        die("Erro de conexão: " . $conexao->connect_error);
    }

    $sql = "INSERT INTO usuarios (nome, sobrenome, cpf, email, senha) VALUES ('$nome', '$sobrenome', '$cpf', '$email', '$senha')";

    if ($conexao->query($sql) === TRUE) {
        header('Location: login.html');
    } else {
        echo "Erro ao cadastrar o usuário: " . $conexao->error;
    }

    $conexao->close();
}

function limpar_entrada($entrada)
{
    $entrada = trim($entrada);
    $entrada = stripslashes($entrada);
    $entrada = htmlspecialchars($entrada);
    return $entrada;
}





