<?php
session_start();
$nomeUsuario = isset($_SESSION['usuario_nome']) ? $_SESSION['usuario_nome'] : '';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/siteVendas/CSS/style.css">
    <link rel="shortcut icon" href="/siteVendas/ico/294668_nike_icon.ico" type="image/x-icon">
    <title>Sabel Sports</title>

</head>

<body>
    <header>
        <div class="menu">
            <div class="mensagem">
                <p id="mensagemBoasVindas">
                    <?php if ($nomeUsuario): ?>
                        Olá, <?php echo $nomeUsuario; ?>
                    <?php endif; ?>
                </p>
            </div>
            <div class="imagem">
                <a href="main.php"><img src="/siteVendas/img/logoSabelSports.png" alt="logoSabelSports"></a>
            </div>
            <div class="right-buttons">
                <a href="#">Ajuda</a>
                <a href="/siteVendas/HTML/login.html">Sair</a>
            </div>
        </div>
        <nav>
            <ul>
                <li><a href="#">Lançamentos</a>
                    <ul class="submenu">
                        <li><a href="#">Opção 1</a></li>
                        <li><a href="#">Opção 2</a></li>
                        <li><a href="#">Opção 3</a></li>
                        <li><a href="#">Opção 4</a></li>
                    </ul>
                </li>
                <li><a href="#">Ofertas</a>
                    <ul class="submenu">
                        <li><a href="#">Opção 1</a></li>
                        <li><a href="#">Opção 2</a></li>
                        <li><a href="#">Opção 3</a></li>
                        <li><a href="#">Opção 4</a></li>
                    </ul>
                </li>
                <li><a href="#">Masculino</a>
                    <ul class="submenu">
                        <li><a href="#">Opção 1</a></li>
                        <li><a href="#">Opção 2</a></li>
                        <li><a href="#">Opção 3</a></li>
                        <li><a href="#">Opção 4</a></li>
                    </ul>
                </li>
                <li><a href="#">Feminino</a>
                    <ul class="submenu">
                        <li><a href="#">Opção 1</a></li>
                        <li><a href="#">Opção 2</a></li>
                        <li><a href="#">Opção 3</a></li>
                        <li><a href="#">Opção 4</a></li>
                    </ul>
                </li>
            </ul>
        </nav>

    </header>
    <main>

        <div class="sidebar">

            <ul class="lista-times">
                <h3>Brasileiros</h3>
                <li data-item="1" class="mb-3"><a href="#" title="Athletico PR" class="btn-link ">Athletico PR</a></li>
                <li data-item="1" class="mb-3"><a href="#" title="Atletico MG" class="btn-link ">Atletico MG</a></li>
                <li data-item="1" class="mb-3"><a href="#" title="Bahia" class="btn-link ">Bahia</a></li>
                <li data-item="1" class="mb-3"><a href="#" title="Botafogo" class="btn-link ">Botafogo</a></li>
                <li data-item="1" class="mb-3"><a href="/siteVendas/Camisas/flamengo.php" title="Flamengo" class="btn-link ">Flamengo</a></li>
                <li data-item="1" class="mb-3"><a href="#" title="Fluminense" class="btn-link ">Fluminense</a></li>
                <li data-item="1" class="mb-3"><a href="#" title="Internacional" class="btn-link ">Internacional</a>
                </li>
                <li data-item="1" class="mb-3"><a href="#" title="Vasco" class="btn-link ">Vasco</a></li>
            </ul>

            <hr>
            <div class="filtro-tamanho">
                <h3>Filtrar por</h3>
                <h4>Tamanho</h4>
                <label><input type="checkbox" name="tamanho[]" value="Pequeno"> Pequeno</label><br>
                <label><input type="checkbox" name="tamanho[]" value="Médio"> Médio</label><br>
                <label><input type="checkbox" name="tamanho[]" value="Grande"> Grande</label><br>
                <label><input type="checkbox" name="tamanho[]" value="Extra Grande"> Extra Grande</label><br>
            </div>
            <div class="button">
                <input type="submit" value="FILTRAR">
            </div>

        </div>

        <div class="camisas">
            <a href="#"><img src="/siteVendas/img/flamengo.png" alt="flamengo"></a>
            <div class="item-camisas">
                <a href="#">Camisa Flamengo 2024</a>
                <div class="price-compare-container">
                    <span class="price-compare">R$299,90</span>
                    <span>|</span>
                    <span class="price">R$169,90</span>
                </div>
            </div>
        </div>
        <div class="camisas">
            <a href="#"><img src="/siteVendas/img/fluminense.png" alt="fluminense"></a>
            <div class="item-camisas">
                <a href="#">Camisa Fluminense 2024</a>
                <div class="price-compare-container">
                    <span class="price-compare">R$299,90</span>
                    <span>|</span>
                    <span class="price">R$169,90</span>
                </div>
            </div>
        </div>
        <div class="camisas">
            <a href="#"><img src="/siteVendas/img/bahia.png" alt="bahia"></a>
            <div class="item-camisas">
                <a href="#">Camisa Bahia 2024</a>
                <div class="price-compare-container">
                    <span class="price-compare">R$299,90</span>
                    <span>|</span>
                    <span class="price">R$169,90</span>
                </div>
            </div>
        </div>
        <div class="camisas">
            <a href="#"><img src="/siteVendas/img/gremio.png" alt="gremio"></a>
            <div class="item-camisas">
                <a href="#">Camisa Gremio 2024</a>
                <div class="price-compare-container">
                    <span class="price-compare">R$299,90</span>
                    <span>|</span>
                    <span class="price">R$169,90</span>
                </div>
            </div>
        </div>
        <div class="camisas">
            <a href="#"><img src="/siteVendas/img/athleticopr.png" alt="athletico-pr"></a>
            <div class="item-camisas">
                <a href="#">Camisa Athletico PR 2024</a>
                <div class="price-compare-container">
                    <span class="price-compare">R$299,90</span>
                    <span>|</span>
                    <span class="price">R$169,90</span>
                </div>
            </div>
        </div>
        <div class="camisas">
            <a href="#"><img src="/siteVendas/img/botafogo.png" alt="botafogo"></a>
            <div class="item-camisas">
                <a href="#">Camisa Botafogo 2024</a>
                <div class="price-compare-container">
                    <span class="price-compare">R$299,90</span>
                    <span>|</span>
                    <span class="price">R$169,90</span>
                </div>
            </div>
        </div>
        <div class="camisas">
            <a href="#"><img src="/siteVendas/img/palmeiras.png" alt="palmeiras"></a>
            <div class="item-camisas">
                <a href="#">Camisa Palmeiras 2024</a>
                <div class="price-compare-container">
                    <span class="price-compare">R$299,90</span>
                    <span>|</span>
                    <span class="price">R$169,90</span>
                </div>
            </div>
        </div>
        <div class="camisas">
            <a href="#"><img src="/siteVendas/img/internacional.png" alt="internacional"></a>
            <div class="item-camisas">
                <a href="#">Camisa Internacional 2024</a>
                <div class="price-compare-container">
                    <span class="price-compare">R$299,90</span>
                    <span>|</span>
                    <span class="price">R$169,90</span>
                </div>
            </div>
        </div>
        <div class="camisas">
            <a href="#"><img src="/siteVendas/img/vasco.png" alt="vasco"></a>
            <div class="item-camisas">
                <a href="#">Camisa Vasco 2024</a>
                <div class="price-compare-container">
                    <span class="price-compare">R$299,90</span>
                    <span>|</span>
                    <span class="price">R$169,90</span>
                </div>
            </div>
        </div>
    </main>
    <footer>
        <p>&copy; 2024 Pedro Sabel.

        </p>
    </footer>

</body>

</html>